# RPA_Provisioning_Performer (unattended, REFramework)

Built on the official UiPath REFramework (Windows, 24.10 branch, MIT licence). Framework files are unchanged except:
* `Framework\Process.xaml` – the provisioning steps below.
* `Framework\SetTransactionStatus.xaml` – on success the queue item **Output** gets `ProvisioningResult` (JSON: RequestId, FolderPath, FolderId, FolderCreated, Assignee, Roles, RoleIds).
* `Data\Config.xlsx` – queue `RPA_Provisioning_Requests` in folder `Shared/RPA Provisioning`, plus setting `ProvisioningConfigPath`.

## Process.xaml (one queue item)
| Step | Workflow | Orchestrator API (2025.10 standalone) |
|---|---|---|
| 1 Validate again | `Framework\LoadProvisioningConfig.xaml`, `Request\ValidateRequest.xaml`, `Provisioning\ResolveProvisioningTarget.xaml` | – |
| 2 Authenticate | `Orchestrator\GetAccessToken.xaml` | `POST {IdentityTokenUrl}` client_credentials |
| 3 Create / get folder | `Orchestrator\GetOrCreateFolder.xaml` | `GET odata/Folders?$filter=FullyQualifiedName eq '…'`, `POST odata/Folders` |
| 4 Role Ids + assignee | `Orchestrator\GetRoleIds.xaml`, `Orchestrator\GetAssigneeId.xaml` | `GET odata/Roles?$filter=Name eq '…'`, `GET odata/Users?$filter=…` |
| 5 Assign + apply roles, verify | `Orchestrator\AssignFolderRoles.xaml` | `GET odata/Folders/UiPath.Server.Configuration.OData.GetUsersForFolder(key=…,includeInherited=false)`, `POST odata/Folders/UiPath.Server.Configuration.OData.AssignUsers` |
| 6 Update queue item | `Framework\SetProgress.xaml` (progress at each step) + SetTransactionStatus output | – |
| 7 Notify | `Notifications\SendNotification.xaml` (SMTP) | – |

All HTTP goes through `Orchestrator\InvokeOrchestratorApi.xaml`: base URL, token, `X-UIPATH-OrganizationUnitId`,
`X-UIPATH-TenantName`, timeout and retry (timeouts, 408, 429, 5xx) come from **ApplicationSettings**.

## Exceptions
* **BusinessRuleException** (no retry): request fails validation, entity/policy/role/assignee missing in config or Orchestrator,
  pinned RoleId mismatch, parent folder missing with `CreateMissingParentFolders = FALSE`. Failure email is sent.
* **System exception** (queue Auto Retry): network, timeouts, HTTP errors, role assignment not visible after assignment.
  The failure email is sent only on the last attempt (`QueueMaxRetryNumber`).
* Re-running is safe: the folder is reused when it exists, roles already granted are kept.

## Open in Studio
Unzip, open `project.json` in Studio 2025.10, restore packages, set `ProvisioningConfigPath` in `Data\Config.xlsx`
(same shared workbook as the requester in production), publish to the queue's folder and add a queue trigger.
