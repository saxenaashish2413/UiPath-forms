# RPA_Change_Request_Requester (attended)

Shows the **RPA Change & Deployment Request** UiPath Form, validates the request against
`RPA_Provisioning_Config.xlsx`, generates the Request ID (`RPA-YYYY-NNNNN`) and adds the item to the
`RPA_Provisioning_Requests` queue. The REFramework performer picks it up from there.

## Open in Studio
1. Unzip, open `project.json` in UiPath Studio 2025.10 (Windows, VB.NET). Let Studio restore packages; if a pinned
   version is not on your feed, accept the newer version Studio offers in **Manage Packages**.
2. **Load the form layout once:** open `Form\ShowRequestForm.xaml`, select **Create Form**, click **Open Form Designer**
   and import `Forms\RPA_Change_Deployment_Request.form.json` (Import button, or paste it into the designer's JSON view), then **Save**.
3. Set `in_ConfigPath` (Main argument) to the shared workbook path for production. Default: `Data\RPA_Provisioning_Config.xlsx`.
4. Run `Main.xaml`.

## Workflows
| File | Does |
|---|---|
| `Main.xaml` | Load config → build entity config → show form until valid or cancelled → submit → confirmation. Any failure: logged, shown to the user, job faulted. |
| `Framework\LoadProvisioningConfig.xaml` | Reads the six sheets (Entities, Policies, EntityPolicyMapping, DeploymentMapping, Roles, ApplicationSettings). |
| `Form\GetEntityConfiguration.xaml` | Entity → Policy list + Deployment list, grouped from the DataTables (no per-entity If/Else). Inactive rows are dropped; mapping problems are logged as warnings. |
| `Form\ShowRequestForm.xaml` | Builds the form input (config, logo, defaults, previous values + error text when re-opened) and runs **Create Form**. Returns the form JSON and whether the user cancelled. |
| `Request\ValidateRequest.xaml` | Server-side validation of every field against the config (same file the performer uses). |
| `Request\SubmitRequestToQueue.xaml` | Concurrency-safe Request ID + **Add Queue Item** with `Reference = Request ID`. |

## Form ↔ workflow contract
| Field key | Direction | Notes |
|---|---|---|
| `EntityConfig` | in | JSON from `GetEntityConfiguration` – drives Entity, Policy Role and Deployment Movement lists |
| `CompanyLogoUrl` | in | data-URI of the file in `ApplicationSettings.CompanyLogoPath` (placeholder when missing) |
| `ValidationMessage` | in | workflow validation errors, shown in a red box at the top when the form is re-opened |
| `ProcessType`, `SelectedEntity`, `SelectedPolicyRoles` (array), `DeploymentMovement`, `RequestTitle`, `RequestDescription`, `BusinessJustification`, `RequestedBy`, `RequesterEmail`, `RequestDate` | out | read from **FormFieldsOutputData** (JSON) |
| `FormAction` | out | `Cancel` when the Cancel button was used |

The Entity → Policy/Deployment refresh runs inside the form (form.io custom data source with *Refresh On = SelectedEntity*
and *Clear Value On Refresh*), using data the workflow built from the workbook. The workflow re-validates everything after Submit,
so a value the form should not have allowed is still rejected.
